public class E extends B
{
  public void method_E()
  {
    // method_B();
  }
}


// B private