public class D extends A
{
  public void method_D()
  {
    method_A();
  }
}