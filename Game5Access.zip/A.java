public class A
{
  public int a;

  public void method_A()
  {
    a= 100;
  }
}


// public 은 가장 일반적인 접근제어자. public 으로 선언된 변수, 매서드 등은 어떠한 자바 프로그램에서든 제한없이 접근 사용가능, 다른 클래서에서 얼마든 상속받거나 접근 가능하다. 
// 특히 생성자는 반드시 public을 사용해야만 한다.