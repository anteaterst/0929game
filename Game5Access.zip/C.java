public class C{
  protected int c;

  protected void method_C()
  {
    c=300;
  }
}

// protected 상속을 위한 접근 제어자. protected선언된 변수, 매서드 등은 해당 클래스를 상속받은 서브클래스에게만 public 동작하고 서브클래스가 아닌 클래스들에게는 private으로 동작한다. 즉, 