public class Main
{
  public static void main(String[] args)
  {
    Dog yourDog= new Dog("벤지", 4);

    yourDog.bark();
    yourDog.bite("우체부");


    Snoopy myDog= new Snoopy();

    myDog.bark(); // 메소드 오버라이딩
    myDog.bite("낸시", 9); // 메소드 오버로딩
  }
}


//  자바에서는 인수의 개수나 종류가 다르기만 하면 얼마든지 같은 이름의 매서드 생성이 가능하다. 이것을 매서드 오버로딩 한다. 이와 비슷하지만 다른 개념인 매서드 오버라이딩 MethodOverriding에서도 클래스의 상속에서 일어나는 다형성의 한 종류이다. 