public class Boy extends Human
{
  public Boy()
  {
    this("소년", 0);
  }

  public Boy(String name, int age)
  {
    super(name, age);
  }

}