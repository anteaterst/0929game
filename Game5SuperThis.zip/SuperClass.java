public class SuperClass
{
  public void print()
  {
    System.out.println("수퍼클래스");
  }
}
