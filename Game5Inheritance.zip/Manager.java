public class Manager extends Employee
{
  String department;

  public Manager(String n, int s, String d)
  {
    super(n,s);
    department= d;
  }

  public void getInformation()
  {
    System.out.println("이름: "+ name +", 부서: "+ department +", 연봉: "+ salary);
  }
}

// c++에서는 여러개의 부모클라스로부터 상속이 가능하지만 자바에서는 오직 하나의 부모로부터만 상속 가능하다. 다중상속이 금지 된다. 